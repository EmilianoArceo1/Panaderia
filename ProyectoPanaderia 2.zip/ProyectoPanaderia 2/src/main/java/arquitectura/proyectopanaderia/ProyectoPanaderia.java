package arquitectura.proyectopanaderia;

/**
 *
 * @author emCarlos Ek
 */
public class ProyectoPanaderia {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
