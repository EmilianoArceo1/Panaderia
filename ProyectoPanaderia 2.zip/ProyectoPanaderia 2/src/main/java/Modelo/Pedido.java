package Modelo;

import java.util.List;

/**
 *
 * @author Carlos Ek
 */
class Pedido {
    private int id;
    private List<Producto> productos;
    private String fechaEntrega;
    private Empleado empleadoAsignado;
    private String descripcion;
    private String tiempoElaboracion;

    public Pedido(int id, List<Producto> productos, String fechaEntrega, Empleado empleadoAsignado, String descripcion, String tiempoElaboracion) {
        this.id = id;
        this.productos = productos;
        this.fechaEntrega = fechaEntrega;
        this.empleadoAsignado = empleadoAsignado;
        this.descripcion = descripcion;
        this.tiempoElaboracion = tiempoElaboracion;
    }

    public Pedido() {
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public Empleado getEmpleadoAsignado() {
        return empleadoAsignado;
    }

    public void setEmpleadoAsignado(Empleado empleadoAsignado) {
        this.empleadoAsignado = empleadoAsignado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTiempoElaboracion() {
        return tiempoElaboracion;
    }

    public void setTiempoElaboracion(String tiempoElaboracion) {
        this.tiempoElaboracion = tiempoElaboracion;
    }
    
}
