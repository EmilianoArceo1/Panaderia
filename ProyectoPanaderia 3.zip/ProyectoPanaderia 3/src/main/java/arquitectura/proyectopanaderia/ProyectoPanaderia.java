package arquitectura.proyectopanaderia;

import Controller.AdminControlador;
import Modelo.Administrador;
import java.util.Scanner;

/**
 *
 * @author emCarlos Ek
 */
public class ProyectoPanaderia {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String peticion = "";
        System.out.println("Login.\nNombre: Adm\nCorreo: adm@gmail.com");
        Administrador administrador = new Administrador(1,"Adm", "adm@gmail.com");
        AdminControlador controlador = new AdminControlador(administrador);
        while(true){
            System.out.print("Peticion: ");
            peticion = scanner.nextLine().trim();
            
        }
    }
}
