/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arquitectura.proyectopanaderia;


import Controller.AdminControlador;
import Controller.Request;
import Controller.Response;
import Modelo.Administrador;

import java.util.HashMap;
import java.util.Map;

public class pruebas {
    public static void main(String[] args) {
        // Crear un administrador para las pruebas
        Administrador administrador = new Administrador(1, "Admin", "admin@example.com");
        AdminControlador controlador = new AdminControlador(administrador);

        // Prueba 1: Agregar un usuario
        Map<String, String> datosAgregarUsuario = new HashMap<>();
        datosAgregarUsuario.put("nombre", "Juan Pérez");
        datosAgregarUsuario.put("correo", "juan.perez@example.com");
        datosAgregarUsuario.put("tipo", "empleado");

        Request requestAgregarUsuario = new Request("usuarios", "agregar", datosAgregarUsuario);
        Response respuestaAgregarUsuario = controlador.gestionarPeticion(requestAgregarUsuario);
        System.out.println(respuestaAgregarUsuario.getMensaje());

        // Prueba 2: Leer usuarios
        Request requestLeerUsuarios = new Request("usuarios", "leer", null);
        Response respuestaLeerUsuarios = controlador.gestionarPeticion(requestLeerUsuarios);
        System.out.println(respuestaLeerUsuarios.getMensaje());
        System.out.println("Usuarios: " + respuestaLeerUsuarios.getDatos());

        // Prueba 3: Actualizar un usuario
        Map<String, String> datosActualizarUsuario = new HashMap<>();
        datosActualizarUsuario.put("id", "1"); // Cambiar según el ID del usuario
        datosActualizarUsuario.put("nombre", "Juan Actualizado");
        datosActualizarUsuario.put("correo", "juan.actualizado@example.com");

        Request requestActualizarUsuario = new Request("usuarios", "actualizar", datosActualizarUsuario);
        Response respuestaActualizarUsuario = controlador.gestionarPeticion(requestActualizarUsuario);
        System.out.println(respuestaActualizarUsuario.getMensaje());

        // Prueba 4: Eliminar un usuario
        Map<String, String> datosEliminarUsuario = new HashMap<>();
        datosEliminarUsuario.put("id", "1"); // Cambiar según el ID del usuario

        Request requestEliminarUsuario = new Request("usuarios", "eliminar", datosEliminarUsuario);
        Response respuestaEliminarUsuario = controlador.gestionarPeticion(requestEliminarUsuario);
        System.out.println(respuestaEliminarUsuario.getMensaje());

        // Prueba 5: Categoría no reconocida
        Request requestCategoriaInvalida = new Request("categorias", "leer", null);
        Response respuestaCategoriaInvalida = controlador.gestionarPeticion(requestCategoriaInvalida);
        System.out.println(respuestaCategoriaInvalida.getMensaje());
    }
}
