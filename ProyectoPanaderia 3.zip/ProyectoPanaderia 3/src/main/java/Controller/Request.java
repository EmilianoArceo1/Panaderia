package Controller;

import java.util.Map;

public class Request {
    private String categoria;
    private String accion;
    private Map<String, String> datos;

    public Request(String categoria, String accion, Map<String, String> datos) {
        this.categoria = categoria;
        this.accion = accion;
        this.datos = datos;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getAccion() {
        return accion;
    }

    public Map<String, String> getDatos() {
        return datos;
    }
}
