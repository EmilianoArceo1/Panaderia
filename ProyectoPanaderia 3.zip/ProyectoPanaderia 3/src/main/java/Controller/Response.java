
package Controller;

/**
 *
 * @author eduardoortiz
 */

public class Response {
    private boolean exito;
    private String mensaje;
    private Object datos;

    public Response(boolean exito, String mensaje) {
        this(exito, mensaje, null);
    }

    public Response(boolean exito, String mensaje, Object datos) {
        this.exito = exito;
        this.mensaje = mensaje;
        this.datos = datos;
    }

    public boolean isExito() {
        return exito;
    }

    public String getMensaje() {
        return mensaje;
    }

    public Object getDatos() {
        return datos;
    }
}
