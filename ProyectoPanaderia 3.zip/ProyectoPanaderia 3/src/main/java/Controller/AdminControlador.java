package Controller;

import Modelo.*;
import java.util.*;

/**
 * Controlador estándar para gestionar solicitudes de Administrador
 * 
 * @author Emiliano Arceo
 */
public class AdminControlador {
    private Administrador administrador;

    // Constructor que inicializa al administrador
    public AdminControlador(Administrador administrador) {
        this.administrador = administrador;
    }

    // Método principal para gestionar peticiones
    public Response gestionarPeticion(Request request) {
        try {
            switch (request.getCategoria().toLowerCase()) {
                case "usuarios":
                    return gestionarUsuarios(request);
                case "pedidos":
                    return gestionarPedidos(request);
                case "productos":
                    return gestionarProductos(request);
                default:
                    return new Response(false, "Categoría no reconocida: " + request.getCategoria());
            }
        } catch (Exception e) {
            return new Response(false, "Error al procesar la solicitud: " + e.getMessage());
        }
    }

    // Gestión de usuarios
    private Response gestionarUsuarios(Request request) {
        switch (request.getAccion().toLowerCase()) {
            case "agregar":
                return agregarUsuario(request.getDatos());
            case "leer":
                return leerUsuarios();
            case "actualizar":
                return actualizarUsuario(request.getDatos());
            case "eliminar":
                return eliminarUsuario(request.getDatos());
            default:
                return new Response(false, "Acción de usuario no reconocida.");
        }
    }

    private Response agregarUsuario(Map<String, String> datos) {
        try {
            String nombre = datos.get("nombre");
            String correo = datos.get("correo");
            String tipo = datos.get("tipo");

            Usuario nuevoUsuario = tipo.equalsIgnoreCase("administrador")
                    ? new Administrador(0, nombre, correo)
                    : new Empleado(0, nombre, correo);

            administrador.añadirUsuario(nuevoUsuario);
            nuevoUsuario.setId(administrador.obtenerUsuarioId(nombre, correo));
            return new Response(true, "Usuario agregado con éxito.");
        } catch (Exception e) {
            return new Response(false, "Error al agregar usuario: " + e.getMessage());
        }
    }

    private Response leerUsuarios() {
        try {
            List<Usuario> usuarios = administrador.verUsuarios();
            return new Response(true, "Usuarios obtenidos con éxito.", usuarios);
        } catch (Exception e) {
            return new Response(false, "Error al leer usuarios: " + e.getMessage());
        }
    }

    private Response actualizarUsuario(Map<String, String> datos) {
        try {
            int id = Integer.parseInt(datos.get("id"));
            String nombre = datos.get("nombre");
            String correo = datos.get("correo");

            administrador.editarUsuario(id, new Usuario(id, nombre, correo));
            return new Response(true, "Usuario actualizado con éxito.");
        } catch (Exception e) {
            return new Response(false, "Error al actualizar usuario: " + e.getMessage());
        }
    }

    private Response eliminarUsuario(Map<String, String> datos) {
        try {
            int id = Integer.parseInt(datos.get("id"));
            administrador.eliminarUsuario(id);
            return new Response(true, "Usuario eliminado con éxito.");
        } catch (Exception e) {
            return new Response(false, "Error al eliminar usuario: " + e.getMessage());
        }
    }

    // Gestión de pedidos
    private Response gestionarPedidos(Request request) {
        // Similar a los métodos de usuario
        return new Response(true, "Gestión de pedidos no implementada todavía.");
    }

    // Gestión de productos
    private Response gestionarProductos(Request request) {
        // Similar a los métodos de usuario
        return new Response(true, "Gestión de productos no implementada todavía.");
    }
}