package Controller;

import Modelo.Empleado;
import Modelo.Pedido;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Controlador para gestionar las acciones del empleado.
 */
public class EmpleadoControlador {
    private Empleado empleado;

    // Constructor que inicializa al empleado
    public EmpleadoControlador(Empleado empleado) {
        this.empleado = empleado;
    }

    // Gestionar peticiones del empleado
    public void gestionarPeticion(String peticion) {
        String[] partes = peticion.split(" ", 2);
        String orden = partes[0].toLowerCase();
        String datos = partes.length > 1 ? partes[1] : "";

        switch (orden) {
            case "pedidos":
                gestionarPedidos(datos);
                break;
            default:
                System.out.println("Error: Acción no reconocida.");
                break;
        }
    }

    // Gestionar pedidos asignados al empleado
    private void gestionarPedidos(String datos) {
        if (datos.isBlank()) {
            System.out.println("Error: Falta la acción para gestionar pedidos.");
            return;
        }

        String[] partes = datos.split(" ", 2);
        String accion = partes[0].toLowerCase();
        String parametros = partes.length > 1 ? partes[1] : "";

        try {
            switch (accion) {
                case "ver":
                    verPedidos();
                    break;
                case "iniciar":
                    iniciarTrabajo(parametros);
                    break;
                case "finalizar":
                    finalizarPedido(parametros);
                    break;
                case "pausar":
                    pausarPedido(parametros);
                    break;
                default:
                    System.out.println("Error: Acción de pedidos no reconocida.");
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error al procesar la petición de pedidos: " + e.getMessage());
        }
    }

    // Ver pedidos asignados al empleado
    private void verPedidos() {
        List<Pedido> pedidos = empleado.verPedidos();
        if (pedidos.isEmpty()) {
            System.out.println("No hay pedidos asignados.");
        } else {
            pedidos.forEach(System.out::println);
        }
    }

    // Iniciar trabajo en un pedido
    private void iniciarTrabajo(String datos) {
        try {
            Map<String, String> parametros = parsearLlaves(datos);
            int idPedido = Integer.parseInt(parametros.get("idPedido"));
            empleado.iniciarTrabajoEnPedido(idPedido);
        } catch (Exception e) {
            System.out.println("Error al iniciar trabajo en el pedido: " + e.getMessage());
        }
    }

    // Finalizar un pedido
    private void finalizarPedido(String datos) {
        try {
            Map<String, String> parametros = parsearLlaves(datos);
            int idPedido = Integer.parseInt(parametros.get("idPedido"));
            empleado.finalizarPedido(idPedido);
        } catch (Exception e) {
            System.out.println("Error al finalizar el pedido: " + e.getMessage());
        }
    }

    // Pausar un pedido
    private void pausarPedido(String datos) {
        try {
            Map<String, String> parametros = parsearLlaves(datos);
            int idPedido = Integer.parseInt(parametros.get("idPedido"));
            empleado.pausarPedido(idPedido);
        } catch (Exception e) {
            System.out.println("Error al pausar el pedido: " + e.getMessage());
        }
    }

    // Método auxiliar para parsear parámetros en formato {clave:valor}
    private Map<String, String> parsearLlaves(String datos) {
        return datos.lines()
                .map(linea -> linea.replaceAll("[{}]", ""))
                .map(par -> par.split(":", 2))
                .collect(Collectors.toMap(par -> par[0].trim(), par -> par[1].trim()));
    }
}
