package Controller;

import Modelo.Usuario;
import Modelo.UsuarioDAO;
import Modelo.Administrador;
import Modelo.Empleado;

public class LoginControlador {

    private UsuarioDAO usuarioDAO;

    public LoginControlador() {
        this.usuarioDAO = new UsuarioDAO();
    }

    // Método de login que recibe solo correo
    public Object login(String correo) {
        // Validamos si existe un usuario con el correo proporcionado
        Usuario usuario = usuarioDAO.obtenerPorCorreo(correo);
        
        if (usuario != null) {
            // Dependiendo del tipo de usuario, devolvemos el controlador adecuado
            if (usuario instanceof Administrador) {
                System.out.println("Bienvenido Administrador!");
                return new AdminControlador((Administrador) usuario);
            } else if (usuario instanceof Empleado) {
                System.out.println("Bienvenido Empleado!");
                return new EmpleadoControlador((Empleado) usuario);
            }
        }
        
        System.out.println("Correo no encontrado.");
        return null;
    }
}
