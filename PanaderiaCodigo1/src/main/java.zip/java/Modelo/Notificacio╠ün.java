package Modelo;

/**
 *
 * @author emili
 */
public class Notificación {
    
}
