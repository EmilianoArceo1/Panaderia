# Panaderia
Este repositorio contiene el código fuente de un Sistema de Gestión para Panadería desarrollado siguiendo el patrón de diseño Modelo-Vista-Controlador (MVC). El objetivo del sistema es organizar y optimizar las operaciones internas de una panadería, desde la gestión de usuarios y productos hasta el seguimiento de pedidos.
