package Modelo;

import java.util.List;

/**
 *
 * @author Carlos Ek
 */
public class Empleado extends Usuario {
    private List<Pedido> pedidosAsignados;

    public Empleado(int id, String nombre, String correo) {
        super(id, nombre, correo);
    }
}
