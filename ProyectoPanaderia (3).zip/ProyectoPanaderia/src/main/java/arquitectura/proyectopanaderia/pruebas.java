/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arquitectura.proyectopanaderia;

import Controller.AdminControlador;
import Controller.EmpleadoControlador;
import Modelo.Administrador;
import Modelo.Empleado;
import Modelo.Pedido;
import Modelo.Producto;
import Modelo.Usuario;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author emili
 */
public class pruebas {
    public static void main(String[] args) {
        // Crear instancias de los usuarios
        Usuario usuarioAdmin = new Administrador(1, "Carlos", "admin@correo.com");
        Usuario usuarioEmpleado = new Empleado(2, "Juan", "empleado@correo.com");

        // Crear instancias de los controladores
        AdminControlador adminControlador = new AdminControlador((Administrador) usuarioAdmin);
        EmpleadoControlador empleadoControlador = new EmpleadoControlador((Empleado) usuarioEmpleado);
        
        System.out.println("Simulando peticiones del administrador:");
        adminControlador.gestionarPeticion("productos agregar {nombre:Pizza,descripcion:Pizza napolitana,precio:12.50,tiempoElaboracion:30min}");
        adminControlador.gestionarPeticion("productos agregar {nombre:Hamburguesa,descripcion:Hamburguesa con queso,precio:8.00,tiempoElaboracion:20min}");
        adminControlador.gestionarPeticion("pedidos agregar {productos:1,2,fechaEntrega:2024-12-05,empleadoId:2,descripcion:Pizza para fiesta,tiempoElaboracion:30min}");
        adminControlador.gestionarPeticion("productos leer");

        // Simulando peticiones del empleado
        System.out.println("\nSimulando peticiones del empleado:");
        empleadoControlador.gestionarPeticion("pedidos ver");
        empleadoControlador.gestionarPeticion("pedidos iniciar {idPedido:1}");
        empleadoControlador.gestionarPeticion("pedidos finalizar {idPedido:1}");

        // Verificación final de pedidos
        System.out.println("\nPedidos después de la gestión:");
        empleadoControlador.gestionarPeticion("pedidos ver");
    }
}
