package Modelo;

/**
 *
 * @author Eduardo Ortiz
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO implements OperacionesDAO<Pedido> {
    private static final String URL = "jdbc:h2:~/test";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    public PedidoDAO() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String createTablePedido = "CREATE TABLE IF NOT EXISTS Pedido ("
                    + "id INT PRIMARY KEY AUTO_INCREMENT, "
                    + "fechaEntrega VARCHAR(50), "
                    + "empleadoAsignadoId INT, "
                    + "descripcion TEXT, "
                    + "tiempoElaboracion VARCHAR(50))";
            String createTableProductos = "CREATE TABLE IF NOT EXISTS ProductoPedido ("
                    + "pedidoId INT, "
                    + "productoId INT)";
            try (Statement stmt = connection.createStatement()) {
                stmt.execute(createTablePedido);
                stmt.execute(createTableProductos);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void agregar(Pedido pedido) {
        String sqlPedido = "INSERT INTO Pedido (fechaEntrega, empleadoAsignadoId, descripcion, tiempoElaboracion) VALUES (?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmtPedido = connection.prepareStatement(sqlPedido, Statement.RETURN_GENERATED_KEYS)) {

            pstmtPedido.setString(1, pedido.getFechaEntrega());
            pstmtPedido.setInt(2, pedido.getEmpleadoAsignado().getId());
            pstmtPedido.setString(3, pedido.getDescripcion());
            pstmtPedido.setString(4, pedido.getTiempoElaboracion());
            pstmtPedido.executeUpdate();

            try (ResultSet generatedKeys = pstmtPedido.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int pedidoId = generatedKeys.getInt(1);
                    agregarProductos(connection, pedidoId, pedido.getProductos());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void agregarProductos(Connection connection, int pedidoId, List<Producto> productos) throws SQLException {
        String sqlProducto = "INSERT INTO ProductoPedido (pedidoId, productoId, nombre, descripcion, precio, tiempoElaboracion) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmtProducto = connection.prepareStatement(sqlProducto)) {
            for (Producto producto : productos) {
                pstmtProducto.setInt(1, pedidoId);
                pstmtProducto.setInt(2, producto.getId());
                pstmtProducto.setString(3, producto.getNombre());
                pstmtProducto.setString(4, producto.getDescripcion());
                pstmtProducto.setDouble(5, producto.getPrecio());
                pstmtProducto.setString(6, producto.getTiempoElaboracion());
                pstmtProducto.addBatch();
            }
            pstmtProducto.executeBatch();
        }
    }


    @Override
    public Pedido obtenerPorId(int id) {
        String sqlPedido = "SELECT * FROM Pedido WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmtPedido = connection.prepareStatement(sqlPedido)) {

            pstmtPedido.setInt(1, id);
            try (ResultSet rsPedido = pstmtPedido.executeQuery()) {
                if (rsPedido.next()) {
                    Pedido pedido = new Pedido();
                    pedido.setId(rsPedido.getInt("id"));
                    pedido.setFechaEntrega(rsPedido.getString("fechaEntrega"));
                    pedido.setEmpleadoAsignado(new Empleado(rsPedido.getInt("empleadoAsignadoId"), "NombreFicticio", "correoejemplo"));
                    pedido.setDescripcion(rsPedido.getString("descripcion"));
                    pedido.setTiempoElaboracion(rsPedido.getString("tiempoElaboracion"));

                    pedido.setProductos(obtenerProductos(connection, id));
                    return pedido;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private List<Producto> obtenerProductos(Connection connection, int pedidoId) throws SQLException {
        String sqlProducto = "SELECT * FROM ProductoPedido WHERE pedidoId = ?";
        List<Producto> productos = new ArrayList<>();
        try (PreparedStatement pstmtProducto = connection.prepareStatement(sqlProducto)) {
            pstmtProducto.setInt(1, pedidoId);
            try (ResultSet rsProducto = pstmtProducto.executeQuery()) {
                while (rsProducto.next()) {
                    productos.add(new Producto(
                            rsProducto.getInt("productoId"),
                            rsProducto.getString("nombre"),
                            rsProducto.getString("descripcion"),
                            rsProducto.getDouble("precio"),
                            rsProducto.getString("tiempoElaboracion")
                    ));
                }
            }
        }
        return productos;
    }


    @Override
    public List<Pedido> obtenerTodos() {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM Pedido";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                pedidos.add(obtenerPorId(rs.getInt("id")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pedidos;
    }

    @Override
    public void actualizar(int id, Pedido pedidoActualizado) {
        String sql = "UPDATE Pedido SET fechaEntrega = ?, empleadoAsignadoId = ?, descripcion = ?, tiempoElaboracion = ? WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {

            pstmt.setString(1, pedidoActualizado.getFechaEntrega());
            pstmt.setInt(2, pedidoActualizado.getEmpleadoAsignado().getId());
            pstmt.setString(3, pedidoActualizado.getDescripcion());
            pstmt.setString(4, pedidoActualizado.getTiempoElaboracion());
            pstmt.setInt(5, id);
            pstmt.executeUpdate();

            // Actualizar productos relacionados
            eliminarProductos(connection, id);
            agregarProductos(connection, id, pedidoActualizado.getProductos());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void eliminarProductos(Connection connection, int pedidoId) throws SQLException {
        String sql = "DELETE FROM ProductoPedido WHERE pedidoId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, pedidoId);
            pstmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) {
        String sqlPedido = "DELETE FROM Pedido WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmtPedido = connection.prepareStatement(sqlPedido)) {

            eliminarProductos(connection, id);
            pstmtPedido.setInt(1, id);
            pstmtPedido.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
