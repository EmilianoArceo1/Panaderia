package Modelo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Carlos Ek
 */
public class Administrador extends Usuario{
    private UsuarioDAO usuarioDAO ;
    private ProductoDAO productoDAO;
    private PedidoDAO pedidoDAO;
    private ClienteDAO clienteDAO;
    
    public Administrador(int id, String nombre, String correo) {
        super(id, nombre, correo);
        usuarioDAO = new UsuarioDAO();
        productoDAO = new ProductoDAO();
        pedidoDAO = new PedidoDAO();
        clienteDAO = new ClienteDAO();
    }
    
    public List<Usuario> verUsuarios(){
         return usuarioDAO.obtenerTodos();
    }
    
    public void añadirUsuario(Usuario usuario){ 
        usuarioDAO.agregar(usuario); 
    }
    
    public void editarUsuario(int idUsuario, Usuario usuarioActualizado){
        usuarioDAO.actualizar(idUsuario, usuarioActualizado);
    }
    
    public void eliminarUsuario(int idUsuario){
        usuarioDAO.eliminar(idUsuario);
    }
    
    public List<Producto> verProductos(){ 
        return productoDAO.obtenerTodos();
    }
    
    public void añadirProducto(Producto producto){ 
        productoDAO.agregar(producto);
    }
    
    public void editarProducto(int idProducto, Producto producto){ 
        productoDAO.actualizar(idProducto, producto);
    }
    
    public void eliminarProducto(int idProducto){ 
        productoDAO.eliminar(idProducto);
    }
    
    public List<Pedido> verPedidos(){ 
        return pedidoDAO.obtenerTodos();
    }
    
    public void añadirPedido(Pedido pedido){ 
        pedidoDAO.agregar(pedido); 
    }
    
    public void editarPedido(int idPedido, Pedido pedidoActualizado){
        pedidoDAO.actualizar(idPedido, pedidoActualizado);
    }
    
    public void eliminarPedido(int idPedido){
        pedidoDAO.eliminar(idPedido);
    }
    
    public List<Cliente> verClientes(){ 
        return clienteDAO.obtenerTodos();
    }
    
    public void añadirCliente(Cliente cliente){ 
        clienteDAO.agregar(cliente); 
    }
    
    public void editarCliente(int idCliente, Cliente clienteActualizado){
        clienteDAO.actualizar(idCliente, clienteActualizado);
    }
    
    public void eliminarCliente(int idCliente){
        clienteDAO.eliminar(idCliente);
    }
    
    public int obtenerUsuarioId(String nombre, String correo){
        return usuarioDAO.obtenerId(correo, correo);
    }
    
    public Empleado obtenerEmpleadoPorId(int idEmpleado){
        return (Empleado) usuarioDAO.obtenerPorId(idEmpleado);
    }
    
        public Pedido obtenerPedidoPorId(int idPedido){
        return pedidoDAO.obtenerPorId(idPedido);
    }
    
    
    public List<Producto> obtenerProductosPorIds(List<Integer> ids) {
        List<Producto> productos = new ArrayList<>();
        for (int id : ids) {
            Producto producto = productoDAO.obtenerPorId(id);
            if (producto != null) {
                productos.add(producto);
            }
        }
        return productos;
    }

    // Método para reasignar un pedido de un empleado a otro
    public void reasignarPedido(Usuario empleadoAntiguo, Usuario nuevoEmpleado, Pedido pedido) {
        if (empleadoAntiguo != null && nuevoEmpleado != null) {
            // Aquí puedes implementar la lógica de reasignación, si es necesario
            pedido.setEmpleadoAsignado((Empleado) nuevoEmpleado);
        }
    }


}
