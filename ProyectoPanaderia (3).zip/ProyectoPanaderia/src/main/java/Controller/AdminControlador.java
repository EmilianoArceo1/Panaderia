package Controller;

import Modelo.Administrador;
import Modelo.Empleado;
import Modelo.Pedido;
import Modelo.Producto;
import Modelo.Usuario;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Emiliano Arceo
 */
public class AdminControlador {
    private Administrador administrador;

    // Constructor que inicializa al administrador
    public AdminControlador(Administrador administrador) {
        this.administrador = administrador;
    }

    // Método principal para gestionar peticiones
    public void gestionarPeticion(String peticion) {
        String[] partes = peticion.split(" ", 2);
        if (partes.length < 2) {
            System.out.println("Error: Formato de petición incorrecto.");
            return;
        }

        String categoria = partes[0].toLowerCase();
        String detalle = partes[1];

        switch (categoria) {
            case "usuarios":
                gestionarUsuarios(detalle);
                break;
            case "pedidos":
                gestionarPedidos(detalle);
                break;
            case "productos":
                gestionarProductos(detalle);
                break;
            default:
                System.out.println("Error: Categoría de gestión no reconocida.");
                break;
        }
    }

    // Gestión de usuarios
    private void gestionarUsuarios(String detalle) {
        String[] partes = detalle.split(" ", 2);
        if (partes.length < 2) {
            System.out.println("Error: Detalles insuficientes para gestionar usuarios.");
            return;
        }

        String accion = partes[0].toLowerCase();
        String datos = partes[1];

        try {
            switch (accion) {
                case "agregar":
                    Map<String, String> datosUsuario = parsearLlaves(datos);
                    String nombre = datosUsuario.get("nombre");
                    String correo = datosUsuario.get("correo");
                    String tipo = datosUsuario.get("tipo");

                    Usuario nuevoUsuario = tipo.equals("administrador")
                            ? new Administrador(0, nombre, correo)
                            : new Empleado(0, nombre, correo);

                    administrador.añadirUsuario(nuevoUsuario);
                    nuevoUsuario.setId(administrador.obtenerUsuarioId(nombre, correo));
                    System.out.println("Usuario agregado con éxito.");
                    break;
                case "actualizar":
                    String[] datosActualizar = datos.split(" ", 3);
                    int idActualizar = Integer.parseInt(datosActualizar[0]);
                    String nuevoNombre = datosActualizar[1];
                    String nuevoCorreo = datosActualizar[2];

                    administrador.editarUsuario(idActualizar, new Usuario(idActualizar, nuevoNombre, nuevoCorreo));
                    System.out.println("Usuario actualizado con éxito.");
                    break;
                case "eliminar":
                    int idEliminar = Integer.parseInt(datos);
                    administrador.eliminarUsuario(idEliminar);
                    System.out.println("Usuario eliminado con éxito.");
                    break;
                case "leer":
                    administrador.verUsuarios().forEach(System.out::println);
                    break;
                default:
                    System.out.println("Error: Acción de usuario no reconocida.");
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error al gestionar usuarios: " + e.getMessage());
        }
    }

    // Gestión de pedidos
    private void gestionarPedidos(String detalle) {
        String[] partes = detalle.split(" ", 2);
        if (partes.length < 2) {
            System.out.println("Error: Detalles insuficientes para gestionar pedidos.");
            return;
        }

        String accion = partes[0].toLowerCase();
        String datos = partes[1];

        try {
            switch (accion) {
                case "agregar":
                    Map<String, String> datosPedido = parsearLlaves(datos);
                    List<Integer> idsProductos = convertirIdsALista(datosPedido.get("productos"));
                    String fechaEntrega = datosPedido.get("fechaEntrega");
                    int empleadoId = Integer.parseInt(datosPedido.get("empleadoId"));
                    String descripcion = datosPedido.get("descripcion");
                    String tiempoElaboracion = datosPedido.get("tiempoElaboracion");

                    List<Producto> productos = administrador.obtenerProductosPorIds(idsProductos);
                    Empleado empleado = administrador.obtenerEmpleadoPorId(empleadoId);

                    Pedido nuevoPedido = new Pedido(0, productos, fechaEntrega, empleado, descripcion, tiempoElaboracion);
                    administrador.añadirPedido(nuevoPedido);
                    System.out.println("Pedido agregado con éxito.");
                    break;
                case "leer":
                    administrador.verPedidos().forEach(System.out::println);
                    break;
                case "actualizar":
                    Map<String, String> datosActualizacion = parsearLlaves(datos);

                    int idPedido = Integer.parseInt(datosActualizacion.get("idPedido"));
                    List<Integer> idsProductosNuevos = convertirIdsALista(datosActualizacion.get("productos"));
                    String nuevaFechaEntrega = datosActualizacion.get("fechaEntrega");
                    int nuevoEmpleadoId = Integer.parseInt(datosActualizacion.get("empleadoId"));
                    String nuevaDescripcion = datosActualizacion.get("descripcion");
                    String nuevoTiempoElaboracion = datosActualizacion.get("tiempoElaboracion");

                    Pedido pedidoExistente = administrador.obtenerPedidoPorId(idPedido);
                    if (pedidoExistente == null) {
                        System.out.println("Error: No se encontró el pedido con ID " + idPedido);
                        break;
                    }

                    List<Producto> productosNuevos = administrador.obtenerProductosPorIds(idsProductosNuevos);
                    Empleado nuevoEmpleado = administrador.obtenerEmpleadoPorId(nuevoEmpleadoId);
                    if (nuevoEmpleado == null) {
                        System.out.println("Error: No se encontró el empleado con ID " + nuevoEmpleadoId);
                        break;
                    }

                    Pedido pedidoActualizado = new Pedido(
                        idPedido, 
                        productosNuevos, 
                        nuevaFechaEntrega, 
                        nuevoEmpleado, 
                        nuevaDescripcion, 
                        nuevoTiempoElaboracion
                    );
                    administrador.editarPedido(idPedido, pedidoActualizado);
                    System.out.println("Pedido actualizado con éxito.");
                        break;

                case "eliminar":
                        Map<String, String> datosEliminacion = parsearLlaves(datos);
                        int idPedidoEliminar = Integer.parseInt(datosEliminacion.get("idPedido"));

                        Pedido pedidoEliminar = administrador.obtenerPedidoPorId(idPedidoEliminar);
                        if (pedidoEliminar == null) {
                            System.out.println("Error: No se encontró el pedido con ID " + idPedidoEliminar);
                            break;
                        }

                        administrador.eliminarPedido(idPedidoEliminar);
                        System.out.println("Pedido eliminado con éxito.");
                    break;
                default:
                    System.out.println("Error: Acción de pedidos no reconocida.");
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error al gestionar pedidos: " + e.getMessage());
        }
    }

    // Gestión de productos
    private void gestionarProductos(String detalle) {
        String[] partes = detalle.split(" ", 2);
        if (partes.length < 2) {
            System.out.println("Error: Detalles insuficientes para gestionar productos.");
            return;
        }

        String accion = partes[0].toLowerCase();
        String datos = partes[1];

        try {
            switch (accion) {
                case "agregar":
                    Map<String, String> datosProducto = parsearLlaves(datos);
                    String nombre = datosProducto.get("nombre");
                    String descripcion = datosProducto.get("descripcion");
                    double precio = Double.parseDouble(datosProducto.get("precio"));
                    String tiempoElaboracion = datosProducto.get("tiempoElaboracion");

                    Producto nuevoProducto = new Producto(0, nombre, descripcion, precio, tiempoElaboracion);
                    administrador.añadirProducto(nuevoProducto);
                    System.out.println("Producto agregado con éxito.");
                    break;
                case "leer":
                    administrador.verProductos().forEach(System.out::println);
                    break;
                case "actualizar":
                        Map<String, String> datosActualizacion = parsearLlaves(datos);

                        int idProducto = Integer.parseInt(datosActualizacion.get("idProducto"));
                        String nuevoNombre = datosActualizacion.get("nombre");
                        String nuevaDescripcion = datosActualizacion.get("descripcion");
                        double nuevoPrecio = Double.parseDouble(datosActualizacion.get("precio"));
                        String nuevoTiempoElaboracion = datosActualizacion.get("tiempoElaboracion");

                        Producto productoExistente = administrador.verProductos()
                                .stream()
                                .filter(producto -> producto.getId() == idProducto)
                                .findFirst()
                                .orElse(null);

                        if (productoExistente == null) {
                            System.out.println("Error: No se encontró el producto con ID " + idProducto);
                            break;
                        }

                        Producto productoActualizado = new Producto(
                            idProducto, 
                            nuevoNombre, 
                            nuevaDescripcion, 
                            nuevoPrecio, 
                            nuevoTiempoElaboracion
                        );
                        administrador.editarProducto(idProducto, productoActualizado);
                        System.out.println("Producto actualizado con éxito.");
                    break;

                case "eliminar":
                        Map<String, String> datosEliminacion = parsearLlaves(datos);
                        int idProductoEliminar = Integer.parseInt(datosEliminacion.get("idProducto"));

                        Producto productoEliminar = administrador.verProductos()
                                .stream()
                                .filter(producto -> producto.getId() == idProductoEliminar)
                                .findFirst()
                                .orElse(null);

                        if (productoEliminar == null) {
                            System.out.println("Error: No se encontró el producto con ID " + idProductoEliminar);
                            break;
                        }

                        administrador.eliminarProducto(idProductoEliminar);
                        System.out.println("Producto eliminado con éxito.");
                    break;
                default:
                    System.out.println("Error: Acción de productos no reconocida.");
                    break;
            }
        } catch (Exception e) {
            System.out.println("Error al gestionar productos: " + e.getMessage());
        }
    }

    // Método auxiliar para analizar datos entre llaves {}
   private Map<String, String> parsearLlaves(String datos) {
        Map<String, String> mapa = new HashMap<>();
        if (datos == null || datos.isEmpty()) {
            return mapa;
        }

        Pattern pattern = Pattern.compile("\\{([^:]+):([^}]+)\\}");
        Matcher matcher = pattern.matcher(datos);

        while (matcher.find()) {
            String clave = matcher.group(1).trim();
            String valor = matcher.group(2).trim();
            mapa.put(clave.toLowerCase(), valor);
        }

        return mapa;
    }

    // Método auxiliar para convertir una cadena de IDs en una lista de enteros
   private List<Integer> convertirIdsALista(String ids) {
        List<Integer> lista = new ArrayList<>();
        for (String id : ids.split(",")) {
            try {
                lista.add(Integer.parseInt(id.trim()));
            } catch (NumberFormatException e) {
                System.out.println("Error: ID no válido - " + id);
            }
        }
        return lista;
    }

}
