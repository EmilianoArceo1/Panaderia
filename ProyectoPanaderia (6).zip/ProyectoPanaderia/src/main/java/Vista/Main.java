package Vista;

/**
 *
 * @author emili
 */
import Controller.AdministradorControlador;
import Modelo.*;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;
import static org.h2.engine.DbObject.USER;

public class Main {
    public static void main(String[] args) {
        String URL = "jdbc:h2:~/test";
         String USER = "sa";
         String PASSWORD = "";

        String dropTables = "DROP TABLE IF EXISTS CLIENTE, EMPLEADO, PEDIDO, PRODUCTO, PRODUCTOPEDIDO, USUARIO";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = connection.createStatement()) {
            stmt.execute(dropTables);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Crear instancias de las clases necesarias
        Empleado empleado1 = new Empleado(1,"Juan Perez", "juan.perez@example.com");
        Empleado empleado2 = new Empleado(2, "Maria Garcia", "maria.garcia@example.com");
        
        Producto producto1 = new Producto("Laptop", "Laptop de 15 pulgadas", 1200.00, "5 horas");
        Producto producto2 = new Producto("Smartphone", "Smartphone con cámara de 48MP", 600.00, "3 horas");
        
        Cliente cliente1 = new Cliente(1, "Carlos Lopez", "123456789");
        Cliente cliente2 = new Cliente(2, "Ana Torres", "987654321");
        
        // Crear un Pedido
        Pedido pedido1 = new Pedido(cliente1, 1, Arrays.asList(producto1, producto2), "2024-12-10", empleado1);
        
        // Crear un administrador
        Administrador admin = new Administrador(1, "Admin", "admin@example.com");
        
        // Crear el controlador
        AdministradorControlador controlador = new AdministradorControlador(admin);
        clearDatabase(controlador);
        // Añadir empleados
        controlador.añadirEmpleado(empleado1);
        controlador.añadirEmpleado(empleado2);
        
        // Ver empleados
        List<Empleado> empleados = controlador.verEmpleados();
        System.out.println("Empleados:");
        empleados.forEach(e -> System.out.println(e.getNombre()));
        
        // Añadir productos
        controlador.añadirProducto(producto1);
        controlador.añadirProducto(producto2);
        
        // Ver productos
        List<Producto> productos = controlador.verProductos();
        System.out.println("Productos:");
        productos.forEach(p -> System.out.println(p.getNombre()));
        
        // Añadir clientes
        controlador.añadirCliente(cliente1);
        controlador.añadirCliente(cliente2);
        
        // Ver clientes
        List<Cliente> clientes = controlador.verClientes();
        System.out.println("Clientes:");
        clientes.forEach(c -> System.out.println(c.getNombre()));
        
        // Añadir pedido
        controlador.añadirPedido(pedido1);
        
        // Ver pedidos
        List<Pedido> pedidos = controlador.verPedidos();
        System.out.println("Pedidos:");
        pedidos.forEach(p -> System.out.println("Pedido de " + p.getCliente().getNombre()));
        
        // Obtener un empleado por su ID
        Empleado empleadoPorId = controlador.obtenerEmpleadoPorId(1);
        System.out.println("Empleado por ID: " + empleadoPorId.getNombre());
        
        // Obtener un cliente por su nombre
        Cliente clientePorNombre = controlador.obtenerClientePorNombre("Carlos Lopez");
        System.out.println("Cliente por nombre: " + clientePorNombre.getNombre());
        
        // Editar un producto
        Producto productoEditado = new Producto("Smartphone", "Smartphone con 5G", 650.00, "3 horas");
        controlador.editarProducto(producto2.getId(), productoEditado);
        
        // Ver productos después de editar
        productos = controlador.verProductos();
        System.out.println("Productos después de editar:");
        productos.forEach(p -> System.out.println(p.getNombre() + ": " + p.getDescripcion()));
        
        // Eliminar un cliente
        controlador.eliminarCliente(cliente1.getId());
        clientes = controlador.verClientes();
        System.out.println("Clientes después de eliminar uno:");
        clientes.forEach(c -> System.out.println(c.getNombre()));
        
        // Eliminar todos los pedidos
        controlador.eliminarTodosPedidos();
        pedidos = controlador.verPedidos();
        System.out.println("Pedidos después de eliminar todos:");
        pedidos.forEach(p -> System.out.println("Pedido de " + p.getCliente().getNombre()));
    }
    
    public static void clearDatabase(AdministradorControlador administrador) {
        // Assuming you have the following functions for clearing data
        administrador.eliminarTodosEmpleados();
        administrador.eliminarTodosProductos();
        administrador.eliminarTodosPedidos();
        administrador.eliminarTodosClientes();
        
        System.out.println("\nBase de datos limpia.");
    }
}
