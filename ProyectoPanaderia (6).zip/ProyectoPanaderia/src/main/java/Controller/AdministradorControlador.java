package Controller;

import Modelo.Administrador;
import Modelo.AdministradorDAO;
import Modelo.Cliente;
import Modelo.ClienteDAO;
import Modelo.Empleado;
import Modelo.EmpleadoDAO;
import Modelo.Pedido;
import Modelo.PedidoDAO;
import Modelo.Producto;
import Modelo.ProductoDAO;
import java.util.List;

public class AdministradorControlador {
    private ProductoDAO productoDAO;
    private PedidoDAO pedidoDAO;
    private ClienteDAO clienteDAO;
    private EmpleadoDAO empleadoDAO;
    private AdministradorDAO administradorDAO;
    private Administrador admin;
    
    public AdministradorControlador(Administrador admin) {
        this.admin = admin;
        clienteDAO = new ClienteDAO();
        empleadoDAO = new EmpleadoDAO();
        productoDAO = new ProductoDAO();
        pedidoDAO = new PedidoDAO();
        administradorDAO = new AdministradorDAO();
    }

    // Método para obtener todos los empleados
    public List<Empleado> verEmpleados() {
        return empleadoDAO.obtenerTodos();
    }
    
    // Método para añadir un empleado
    public void añadirEmpleado(Empleado empleado) {
        empleadoDAO.agregar(empleado);
    }
    
    // Método para editar un empleado
    public void editarEmpleado(int idEmpleado, Empleado empleadoActualizado) {
        empleadoDAO.actualizar(idEmpleado, empleadoActualizado);
    }
    
    // Método para eliminar un empleado
    public void eliminarEmpleado(int idEmpleado) {
        empleadoDAO.eliminar(idEmpleado);
    }

    // Método para eliminar todos los empleados
    public void eliminarTodosEmpleados() {
        empleadoDAO.eliminarTodos();
    }

    // Métodos para manejar productos
    public List<Producto> verProductos() {
        return productoDAO.obtenerTodos();
    }

    public void añadirProducto(Producto producto) {
        productoDAO.agregar(producto);
    }

    public void editarProducto(int idProducto, Producto productoActualizado) {
        productoDAO.actualizar(idProducto, productoActualizado);
    }

    public void eliminarProducto(int idProducto) {
        productoDAO.eliminar(idProducto);
    }

    // Método para eliminar todos los productos
    public void eliminarTodosProductos() {
        productoDAO.eliminarTodos();
    }

    // Métodos para manejar pedidos
    public List<Pedido> verPedidos() {
        return pedidoDAO.obtenerTodos();
    }

    public void añadirPedido(Pedido pedido) {
        pedidoDAO.agregar(pedido);
    }

    public void editarPedido(int idPedido, Pedido pedidoActualizado) {
        pedidoDAO.actualizar(idPedido, pedidoActualizado);
    }

    public void eliminarPedido(int idPedido) {
        pedidoDAO.eliminar(idPedido);
    }

    // Método para eliminar todos los pedidos
    public void eliminarTodosPedidos() {
        pedidoDAO.eliminarTodos();
    }

    // Métodos para manejar clientes
    public List<Cliente> verClientes() {
        return clienteDAO.obtenerTodos();
    }

    public int añadirCliente(Cliente cliente) {
        return clienteDAO.agregar(cliente);
    }

    public void editarCliente(int idCliente, Cliente clienteActualizado) {
        clienteDAO.actualizar(idCliente, clienteActualizado);
    }

    public void eliminarCliente(int idCliente) {
        clienteDAO.eliminar(idCliente);
    }

    // Método para eliminar todos los clientes
    public void eliminarTodosClientes() {
        clienteDAO.eliminarTodos();
    }
    
    public int añadirAdministrador(Administrador administrador){
        return administradorDAO.agregar(administrador);
    }
    
    // Métodos adicionales
    public Empleado obtenerEmpleadoPorId(int idEmpleado) {
        return empleadoDAO.obtenerPorId(idEmpleado);
    }

    public Empleado obtenerEmpleadoPorCorreo(String correoEmpleado) {
        return empleadoDAO.obtenerPorCorreo(correoEmpleado);
    }

    public List<Producto> obtenerProductosPorIds(List<Integer> ids) {
        return productoDAO.obtenerPorIds(ids);
    }

    public Producto obtenerProductoPorId(int id) {
        return productoDAO.obtenerPorId(id);
    }

    public Producto obtenerProductoPorNombre(String nombreProducto) {
        return productoDAO.obtenerProductoPorNombre(nombreProducto);
    }
    
    public Cliente obtenerClientePorNombre(String nombre){
        return clienteDAO.obtenerPorNombre(nombre);
    }

    public List<Administrador> getAdministradores() {
        return administradorDAO.obtenerTodos();
    }
}
