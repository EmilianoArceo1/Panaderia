package Controller;

import Modelo.AdministradorDAO;
import Modelo.EmpleadoDAO;


public class LoginControlador {

    private EmpleadoDAO empleadoDAO;
    private AdministradorDAO adminDAO;

    public LoginControlador() {
        
    }

    // Método de login que recibe solo correo
    public Object login(String correo) {
        
        
        
        System.out.println("Correo no encontrado.");
        return null;
    }
}
