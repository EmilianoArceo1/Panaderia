package Modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO implements OperacionesDAO<Pedido> {
    private static final String URL = "jdbc:h2:~/test";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    public PedidoDAO() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String createTablePedido = "CREATE TABLE IF NOT EXISTS Pedido (" +
                "id INT PRIMARY KEY AUTO_INCREMENT, " +
                "fechaEntrega VARCHAR(50), " +
                "empleadoAsignadoId INT, " +
                "descripcion TEXT, " +
                "clienteId INT, " + // Se agrega la columna clienteId
                "FOREIGN KEY (clienteId) REFERENCES Cliente(id))";  // Relacionamos clienteId con la tabla Cliente

            String createTableProductos = "CREATE TABLE IF NOT EXISTS ProductoPedido (" +
                    "pedidoId INT, " +
                    "productoId INT)";
            try (Statement stmt = connection.createStatement()) {
                stmt.execute(createTablePedido);
                stmt.execute(createTableProductos);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    

    public int agregar(Pedido pedido) {
    // SQL para insertar el pedido
    String sqlPedido = "INSERT INTO Pedido (fechaEntrega, empleadoAsignadoId, descripcion, clienteId) VALUES (?, ?, ?, ?)";
    
    try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
        // Iniciar transacción
        connection.setAutoCommit(false);

        try (PreparedStatement pstmtPedido = connection.prepareStatement(sqlPedido, Statement.RETURN_GENERATED_KEYS)) {

            // Asignar los valores con tipos compatibles
            pstmtPedido.setString(1, pedido.getFechaEntrega()); // Tipo String -> Fecha
            pstmtPedido.setInt(2, pedido.getEmpleadoAsignado().getId()); // Tipo int -> ID del empleado
            pstmtPedido.setString(3, pedido.getDescripcion()); // Tipo String -> Descripción
            pstmtPedido.setInt(4, pedido.getCliente().getId()); // Asignamos el clienteId

            // Ejecutar la inserción
            pstmtPedido.executeUpdate();
            // Obtener la clave generada para el nuevo pedido
            try (ResultSet generatedKeys = pstmtPedido.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int pedidoId = generatedKeys.getInt(1); // Obtener el ID generado para el pedido
                    agregarProductos(connection, pedidoId, pedido.getProductos());
                    return generatedKeys.getInt(1);
                }
            }

            // Confirmar la transacción
            connection.commit();
        } catch (SQLException e) {
            // Si ocurre un error, hacer rollback
            connection.rollback();
            throw e; // Re-throw para manejarlo fuera
        }
    } catch (SQLException e) {
        e.printStackTrace(); // Manejo de error, reemplazar con un logger si es necesario
    }
    return -1;
}


private void agregarProductos(Connection connection, int pedidoId, List<Producto> productos) throws SQLException {
    // SQL para insertar productos en la tabla intermedia
    String sqlProducto = "INSERT INTO ProductoPedido (pedidoId, productoId) VALUES (?, ?)";
    
    try (PreparedStatement pstmtProducto = connection.prepareStatement(sqlProducto)) {
        for (Producto producto : productos) {
            // Asegurarse de que los tipos de datos sean compatibles
            pstmtProducto.setInt(1, pedidoId); // Tipo int -> ID del pedido
            pstmtProducto.setInt(2, producto.getId()); // Tipo int -> ID del producto

            pstmtProducto.addBatch(); // Añadir a batch
        }

        // Ejecutar el batch
        pstmtProducto.executeBatch();
    }
}

    @Override
    public Pedido obtenerPorId(int id) {
        String sqlPedido = "SELECT * FROM Pedido WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmtPedido = connection.prepareStatement(sqlPedido)) {

            pstmtPedido.setInt(1, id);
            try (ResultSet rsPedido = pstmtPedido.executeQuery()) {
                if (rsPedido.next()) {
                    Pedido pedido = new Pedido();
                    pedido.setId(rsPedido.getInt("id"));
                    pedido.setFechaEntrega(rsPedido.getString("fechaEntrega"));
                    pedido.setDescripcion(rsPedido.getString("descripcion"));

                    // Obtener el empleado asignado con los datos reales desde la base de datos
                    int empleadoId = rsPedido.getInt("empleadoAsignadoId");
                    Empleado empleado = obtenerEmpleadoPorId(empleadoId); // Método para obtener los datos del empleado real
                    pedido.setEmpleadoAsignado(empleado);

                    // Recoger el cliente asociado al pedido (esto debe coincidir con tu diseño de base de datos)
                    int clienteId = rsPedido.getInt("clienteId");
                    Cliente cliente = obtenerClientePorId(clienteId); // Método para obtener el cliente desde la base de datos
                    pedido.setCliente(cliente);

                    pedido.setProductos(obtenerProductos(connection, id));
                    return pedido;
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Empleado obtenerEmpleadoPorId(int id) {
    String sqlEmpleado = "SELECT * FROM Empleado WHERE id = ?";
    try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
         PreparedStatement pstmtEmpleado = connection.prepareStatement(sqlEmpleado)) {
        pstmtEmpleado.setInt(1, id);
        try (ResultSet rsEmpleado = pstmtEmpleado.executeQuery()) {
            if (rsEmpleado.next()) {
                // Crear el objeto Empleado con los datos obtenidos
                return new Empleado(
                        rsEmpleado.getInt("id"),
                        rsEmpleado.getString("nombre"),
                        rsEmpleado.getString("email")
                );
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null; // Si no se encuentra el empleado, retornamos null
}


    private Cliente obtenerClientePorId(int id) {
        String sqlCliente = "SELECT * FROM Cliente WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmtCliente = connection.prepareStatement(sqlCliente)) {
            pstmtCliente.setInt(1, id);
            try (ResultSet rsCliente = pstmtCliente.executeQuery()) {
                if (rsCliente.next()) {
                    // Crear el objeto Cliente con los datos obtenidos
                    return new Cliente(rsCliente.getInt("id"),rsCliente.getString("nombre"), rsCliente.getString("telefono"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    private List<Producto> obtenerProductos(Connection connection, int pedidoId) throws SQLException {
        String sqlProducto = "SELECT * FROM ProductoPedido WHERE pedidoId = ?";
        List<Producto> productos = new ArrayList<>();
        try (PreparedStatement pstmtProducto = connection.prepareStatement(sqlProducto)) {
            pstmtProducto.setInt(1, pedidoId);
            try (ResultSet rsProducto = pstmtProducto.executeQuery()) {
                while (rsProducto.next()) {
                    int productoId = rsProducto.getInt("productoId");
                    Producto producto = obtenerProductoPorId(productoId);
                    if (producto != null) {
                        productos.add(producto);
                    }
                }
            }
        }
        return productos;
    }

    private Producto obtenerProductoPorId(int id) {
        String sql = "SELECT * FROM Producto WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Producto(
                            rs.getString("nombre"),
                            rs.getString("descripcion"),
                            rs.getDouble("precio"),
                            rs.getString("tiempoElaboracion")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Pedido> obtenerTodos() {
        List<Pedido> pedidos = new ArrayList<>();
        String sql = "SELECT * FROM Pedido";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                pedidos.add(obtenerPorId(rs.getInt("id")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pedidos;
    }

    @Override
    public void actualizar(int id, Pedido pedidoActualizado) {
        String sql = "UPDATE Pedido SET fechaEntrega = ?, empleadoAsignadoId = ?, descripcion = ? WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {

            pstmt.setString(1, pedidoActualizado.getFechaEntrega());
            pstmt.setInt(2, pedidoActualizado.getEmpleadoAsignado().getId());
            pstmt.setString(3, pedidoActualizado.getDescripcion());
            pstmt.setInt(4, id);
            pstmt.executeUpdate();

            eliminarProductos(connection, id);
            agregarProductos(connection, id, pedidoActualizado.getProductos());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void eliminarProductos(Connection connection, int pedidoId) throws SQLException {
        String sql = "DELETE FROM ProductoPedido WHERE pedidoId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, pedidoId);
            pstmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) {
        String sqlPedido = "DELETE FROM Pedido WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmtPedido = connection.prepareStatement(sqlPedido)) {

            eliminarProductos(connection, id);
            pstmtPedido.setInt(1, id);
            pstmtPedido.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     public void eliminarTodos() {
        String sql = "DELETE FROM Empleado";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        String sql2 = "SELECT TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'PUBLIC' ORDER BY TABLE_NAME, ORDINAL_POSITION";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql2)) {

            while (rs.next()) {
                String tableName = rs.getString("TABLE_NAME");
                String columnName = rs.getString("COLUMN_NAME");
                System.out.println("Tabla: " + tableName + ", Columna: " + columnName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}

