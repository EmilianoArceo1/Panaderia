package Modelo;

public class Administrador extends Usuario {
    
    public Administrador(int id, String nombre, String correo) {
        super(id, nombre, correo);
    }

    public Administrador(String nombre, String correo) {
        super(nombre, correo);
    }

}
