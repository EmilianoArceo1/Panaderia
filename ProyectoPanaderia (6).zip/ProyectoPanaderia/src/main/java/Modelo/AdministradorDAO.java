package Modelo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdministradorDAO implements OperacionesDAO<Administrador> {
    private static final String URL = "jdbc:h2:~/test";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    public AdministradorDAO() {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            String createTableAdministrador = "CREATE TABLE IF NOT EXISTS Administrador ("
                    + "id INT PRIMARY KEY AUTO_INCREMENT, "
                    + "nombre VARCHAR(100), "
                    + "email VARCHAR(100))";
            try (Statement stmt = connection.createStatement()) {
                stmt.execute(createTableAdministrador);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    @Override
    public int agregar(Administrador administrador) {
        String sql = "INSERT INTO Administrador (nombre, email) VALUES (?, ?)";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, administrador.getNombre());
            pstmt.setString(2, administrador.getCorreo());
            pstmt.executeUpdate();
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1); // Retorna el ID generado
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @Override
    public Administrador obtenerPorId(int id) {
        String sql = "SELECT * FROM Administrador WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Administrador(rs.getInt("id"),rs.getString("nombre"), rs.getString("email"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Administrador> obtenerTodos() {
        List<Administrador> administradores = new ArrayList<>();
        String sql = "SELECT * FROM Administrador";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                administradores.add(new Administrador(rs.getInt("id"),rs.getString("nombre"), rs.getString("email")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return administradores;
    }

    @Override
    public void actualizar(int id, Administrador administradorActualizado) {
        String sql = "UPDATE Administrador SET nombre = ?, email = ? WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, administradorActualizado.getNombre());
            pstmt.setString(2, administradorActualizado.getCorreo());
            pstmt.setInt(4, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminar(int id) {
        String sql = "DELETE FROM Administrador WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
     public void eliminarTodos() {
        String sql = "DELETE FROM Administrador";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
