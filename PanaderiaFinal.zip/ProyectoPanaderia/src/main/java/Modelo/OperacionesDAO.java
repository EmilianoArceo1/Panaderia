package Modelo;

/**
 *
 * @author Eduardo Ortiz
 */
import java.util.List;

public interface OperacionesDAO<T> {
    int agregar(T objeto);
    T obtenerPorId(int id);
    List<T> obtenerTodos();
    void actualizar(int id, T objetoActualizado);
    void eliminar(int id);
}
