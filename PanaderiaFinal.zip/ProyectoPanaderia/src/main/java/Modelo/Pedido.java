package Modelo;

import java.util.List;

/**
 *
 * @author Carlos Ek
 */
public class Pedido {
    private int id;
    private List<Producto> productos;
    private String fechaEntrega;
    private Empleado empleadoAsignado;
    private String tiempoElaboracion;
    private int prioridad;
    private Cliente cliente;

    public Pedido(int id, Cliente cliente, int prioridad, List<Producto> productos, String fechaEntrega, Empleado empleadoAsignado) {
        this.id = id;
        this.cliente = cliente;
        this.prioridad = prioridad;
        this.productos = productos;
        this.fechaEntrega = fechaEntrega;
        this.empleadoAsignado = empleadoAsignado;
    }

    public Pedido(Cliente cliente, int prioridad, List<Producto> productos, String fechaEntrega, Empleado empleadoAsignado) {
        this.cliente = cliente;
        this.prioridad = prioridad;
        this.productos = productos;
        this.fechaEntrega = fechaEntrega;
        this.empleadoAsignado = empleadoAsignado;
    }

    Pedido() {

    }

   

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public Empleado getEmpleadoAsignado() {
        return empleadoAsignado;
    }

    public void setEmpleadoAsignado(Empleado empleadoAsignado) {
        this.empleadoAsignado = empleadoAsignado;
    }
    public String getTiempoElaboracion() {
        return tiempoElaboracion;
    }

    public void setTiempoElaboracion(String tiempoElaboracion) {
        this.tiempoElaboracion = tiempoElaboracion;
    }
    
}
