package Controller;

import Modelo.Administrador;
import Modelo.Cliente;
import Modelo.Empleado;
import Modelo.Pedido;
import Modelo.PedidoDAO;
import Modelo.Producto;
import Modelo.ProductoDAO;
import java.util.List;

/**
 * Controlador para gestionar las acciones del empleado.
 */
public class EmpleadoControlador {

    private Empleado empleado;
    private ProductoDAO productoDAO;
    private PedidoDAO pedidoDAO;

    // Constructor que inicializa al empleado
    public EmpleadoControlador(Empleado empleado) {
        this.empleado = empleado;
        this.productoDAO = new ProductoDAO();
        this.pedidoDAO = new PedidoDAO();
    }

    // Métodos para manejar productos
    public List<Producto> verProductos() {
        return productoDAO.obtenerTodos();
    }

    public void añadirProducto(Producto producto) {
        productoDAO.agregar(producto);
    }

    public void editarProducto(int idProducto, Producto productoActualizado) {
        productoDAO.actualizar(idProducto, productoActualizado);
    }

    public void eliminarProducto(int idProducto) {
        productoDAO.eliminar(idProducto);
    }

    // Método para eliminar todos los productos
    public void eliminarTodosProductos() {
        productoDAO.eliminarTodos();
    }

    // Métodos para manejar pedidos
    public List<Pedido> verPedidos() {
        return pedidoDAO.obtenerTodos();
    }

    public void añadirPedido(Pedido pedido) {
        pedidoDAO.agregar(pedido);
    }

    public void editarPedido(int idPedido, Pedido pedidoActualizado) {
        pedidoDAO.actualizar(idPedido, pedidoActualizado);
    }

    public void eliminarPedido(int idPedido) {
        pedidoDAO.eliminar(idPedido);
    }

    // Método para eliminar todos los pedidos
    public void eliminarTodosPedidos() {
        pedidoDAO.eliminarTodos();
    }

    public List<Pedido> obtenerPedidosPorEmpleado(int empleadoId) {
        return pedidoDAO.obtenerPedidosPorEmpleado(empleadoId);
    }
    
    public  Pedido obtenerPedidoPorEmpleadoYId(int empleadoId, int pedidoId){
        return pedidoDAO.obtenerPedidoPorEmpleadoYId( empleadoId,  pedidoId);
    }

    public List<Producto> obtenerProductosPorIds(List<Integer> ids) {
        return productoDAO.obtenerPorIds(ids);
    }

    public Producto obtenerProductoPorId(int id) {
        return productoDAO.obtenerPorId(id);
    }

}
