package Controller;

import Modelo.AdministradorDAO;
import Modelo.EmpleadoDAO;

public class LoginControlador {

    private AdministradorDAO administradorDAO;
    private EmpleadoDAO empleadoDAO;

    public LoginControlador() {
        this.administradorDAO = new AdministradorDAO();
        this.empleadoDAO = new EmpleadoDAO();
    }

    public String login(String correo, String contraseña) {
        if (administradorDAO.validarAdministrador(correo, contraseña)) {
            return "administrador"; // Si es un administrador válido
        }

        // Si no es Administrador, intentar validar como Empleado
        if (empleadoDAO.validarEmpleado(correo, contraseña)) {
            return "empleado"; // Si es un empleado válido
        }

        // Si no se encuentra en ninguna tabla, retorno falso
        return "invalido";
    }
}